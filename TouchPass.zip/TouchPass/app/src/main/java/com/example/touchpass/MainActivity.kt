package com.example.touchpass

import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.*
import android.util.Log
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.touchpass.ui.theme.TouchPassTheme
import kotlinx.coroutines.*
import java.io.IOException
import java.io.OutputStreamWriter

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var vibrator: Vibrator
    private var coroutineScope = CoroutineScope(Dispatchers.IO)
    private var outputStreamWriter: OutputStreamWriter? = null
    private var lastUri: Uri? = null

    private val requestDirectoryAccess = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            lastUri = uri  // Save the directory URI
        }
    }

    @OptIn(ExperimentalFoundationApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestDirectoryAccess.launch(null)  // Request directory access on app start
        setContent {
            TouchPassTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        VibrateButton(modifier = Modifier
                            .size(500.dp, 100.dp)
                            .padding(32.dp)
                            .combinedClickable(
                                enabled = true,
                                onClick = { startRecordingAndVibrate() },
                                onLongClick = { startRecordingAndVibrate() }
                            )
                            .background(color = MaterialTheme.colorScheme.background)
                        )
                    }
                }
            }
        }
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    private fun startRecordingAndVibrate() {
        setupNewFile()  // Set up a new file for writing
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        sensorManager.registerListener(this, accelerometer, 250)
        coroutineScope.launch {
            delay(10)
            vibratePhone(5)  // Vibrate for 0.005 seconds
            delay(10)  // Delay
            vibratePhone(90)  // Vibrate again for 0.09 seconds
            delay(100)  // Delay 10 + 90 sec
            vibratePhone(90)  // Vibrate again for 0.09 seconds
            delay(100)  // Delay 10 + 90 sec
            vibratePhone(90)  // Vibrate again for 0.09 seconds
            delay(300)  // Delay 10 + 90 sec
            sensorManager.unregisterListener(this@MainActivity)
            outputStreamWriter?.flush()
            outputStreamWriter?.close()
            outputStreamWriter = null  // Reset the writer
        }
    }

    private fun setupNewFile() {
        lastUri?.let { directoryUri ->
            val fileName = "accelerometer_data_${System.currentTimeMillis()}.csv"
            val newFileUri = DocumentsContract.buildDocumentUriUsingTree(
                directoryUri,
                DocumentsContract.getTreeDocumentId(directoryUri)
            )

            val fileUri = DocumentsContract.createDocument(
                contentResolver,
                newFileUri,
                "text/csv",
                fileName
            )

            fileUri?.let {
                contentResolver.openOutputStream(it)?.let { outputStream ->
                    outputStreamWriter?.close()  // Close the previous writer if exists
                    outputStreamWriter = OutputStreamWriter(outputStream)
                    outputStreamWriter?.write("Time,X,Y,Z\n")
                }
            }
        } ?: run {
            Log.e("MainActivity", "Directory URI is not set.")
        }
    }

    private fun vibratePhone(duration: Long) {
        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
    }



    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_LINEAR_ACCELERATION) {
            val currentTime = System.currentTimeMillis()
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            outputStreamWriter?.apply {
                write("$currentTime,$x,$y,$z\n")
//                flush()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
        coroutineScope.cancel()
        try {
            outputStreamWriter?.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}

@Composable
fun VibrateButton(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.TopCenter
    ) {
        Text("Hold me to Record Data")
    }
}